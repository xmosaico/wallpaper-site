
import { useState } from 'react';

function App() {
  const [unlocked, setUnlocked] = useState(false);

  const handleUnlock = () => {
    window.open("https://linkvertise.com/your-ad-link", "_blank");
    setUnlocked(true);
  };

  return (
    <div style={{textAlign: 'center', padding: '2rem', fontFamily: 'Arial', background: '#111', color: '#fff', minHeight: '100vh'}}>
      <h1>Free HD Wallpaper</h1>
      <p>Watch an ad to unlock and download the wallpaper.</p>
      <img src="https://via.placeholder.com/400x250.png?text=Wallpaper+Preview" alt="Preview" style={{borderRadius: '1rem', marginBottom: '1rem'}} />
      {!unlocked ? (
        <button onClick={handleUnlock} style={{padding: '1rem 2rem', fontSize: '1rem', borderRadius: '1rem'}}>Unlock Wallpaper</button>
      ) : (
        <a href="https://drive.google.com/your-download-link" target="_blank" rel="noopener noreferrer" style={{padding: '1rem 2rem', backgroundColor: '#4caf50', borderRadius: '1rem', color: 'white', textDecoration: 'none'}}>Download Now</a>
      )}
    </div>
  );
}

export default App;
